require('../../modules/es6.object.to-string');
module.exports = require('../../modules/_wks-ext').f('toStringTag');