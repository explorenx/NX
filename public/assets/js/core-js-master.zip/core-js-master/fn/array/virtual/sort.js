require('../../../modules/es6.array.sort');
module.exports = require('../../../modules/_entry-virtual')('Array').sort;