require('../../modules/es7.array.includes');
module.exports = require('../../modules/_core').Array.includes;