require('../../modules/es6.function.bind');
module.exports = require('../../modules/_core').Function.bind;