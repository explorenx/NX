require('../../modules/es6.reflect.get-own-property-descriptor');
module.exports = require('../../modules/_core').Reflect.getOwnPropertyDescriptor;