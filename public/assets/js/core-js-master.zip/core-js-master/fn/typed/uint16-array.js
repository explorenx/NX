require('../../modules/es6.typed.uint16-array');
module.exports = require('../../modules/_core').Uint16Array;