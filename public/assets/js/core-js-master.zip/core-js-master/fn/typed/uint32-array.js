require('../../modules/es6.typed.uint32-array');
module.exports = require('../../modules/_core').Uint32Array;