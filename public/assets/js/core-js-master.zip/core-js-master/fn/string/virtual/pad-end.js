require('../../../modules/es7.string.pad-end');
module.exports = require('../../../modules/_entry-virtual')('String').padEnd;