require('../../modules/core.object.is-object');
module.exports = require('../../modules/_core').Object.isObject;