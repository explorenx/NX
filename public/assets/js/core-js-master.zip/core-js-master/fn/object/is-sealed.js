require('../../modules/es6.object.is-sealed');
module.exports = require('../../modules/_core').Object.isSealed;